<script src="bootstrap4/jquery/jquery.min.js"></script>
<script src="bootstrap4/jquery/accounting.min.js"></script>
<script src="bootstrap4/jquery/sweetalert.min.js"></script>
<script src="bootstrap4/js/bootstrap.bundle.min.js"></script>
<script src="bootstrap4/js/typeahead.js"></script>
