<title>POS.PHP</title>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
<link rel="icon" type="image/png" sizes="180x180" href="images/icon.png">
<link rel="stylesheet" type="text/css" href="bootstrap4/css/bootstrap.min.css">
<link rel="stylesheet" type="text/css" href="bootstrap4/css/style.css">
<link rel="stylesheet" href="bootstrap4/css/all.min.css"/>
<link rel="stylesheet" href="bootstrap4/css/typeahead.css"/>
<script src="bootstrap4/jquery/sweetalert.min.js"></script>
